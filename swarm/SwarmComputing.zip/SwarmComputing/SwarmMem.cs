﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Spinach
{
    public class SwarmMem
    {
        public void prettyprint()
        {
            Console.WriteLine("hello world");
        }
    }
}
