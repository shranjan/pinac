﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Threading;

namespace Spinach
{
    public partial class AsynchronousSocketListener
    {
        //Delegates and Events
        public delegate void ChatEventHandler(string Uname, string ChatMsg);
        public event ChatEventHandler ChatChanged;

        public delegate void ErrorEventHandler(int ErrorCode,string ErrorMsg);
        public event ErrorEventHandler ErrorChanged;

        public delegate void PrivelageEventHandler(string[] strPrev);
        public event PrivelageEventHandler AddPrev;
        public event PrivelageEventHandler ChngPermission;
        public event PrivelageEventHandler TransOwner;


        private void parseMsg(String msg)
        {
            String type=" ";
            XDocument xml = XDocument.Parse(msg);
            var q1 = from x in xml.Elements() select x;
            if (q1.ElementAt(0).Name.ToString() == "root")
            {
                var q = from x in xml.Descendants()
                        where (x.Name == "root")
                        select x;
                foreach (var elem in q)
                    type = elem.Attributes().ElementAt(0).Value;

                if (type == "Connection")
                    getConnectionRequestMsg(msg);
                else if (type == "IPtoPeer")
                    getIPtoPeerMsg(msg);
                else if (type == "HeartBeatRequest")
                    getHeartBeatRequestMsg(msg);
                else if (type == "HeartBeatReply")
                    getHeartBeatReplyMsg(msg);
                else if (type == "Master")
                    getMasterMsg(msg);
                else if (type == "Backup")
                    getBackupMsg(msg);
                //else if (type == "Run")
                //    getRun(ref mPeer);
                //else if (type == "RunSucess")
                //    getRunSucess();
                //else if (type == "RunFail")
                //    getRunFail();
                //else if (type == "ReRun")
                //    getReRun(ref mPeer);
                else if (type == "Chat")
                    getChatMsg(msg);
                else if (type == "Error")
                    getErrorMsg(msg);
                else if (type == "Disconnect")
                    getDisconnectMsg(msg);
            }
            else if (q1.ElementAt(0).Name.ToString() == "NewProg")
            {
                SwarmMemoryCaller smc = new SwarmMemoryCaller();
                string[] temp=smc.addPermission(msg);
                if (AddPrev != null)
                    AddPrev(temp);
            }
            else if (q1.ElementAt(0).Name.ToString() == "PermissionChange")
            {
                SwarmMemoryCaller smc = new SwarmMemoryCaller();
                string[] temp = smc.changePermission(msg);
                if (ChngPermission != null)
                    ChngPermission(temp);
            }
            else if (q1.ElementAt(0).Name.ToString() == "ChangeOwner")
            {
                SwarmMemoryCaller smc = new SwarmMemoryCaller();
                string[] temp = smc.changeOwner(msg);
                if (TransOwner != null)
                    TransOwner(temp);
            }             
        }

        private void getConnectionRequestMsg(String msg)
        {
            String ip;
            String port;
            String name;
            String cpu;
            Thread t1 = null;
            Thread t2 = null;
            Thread t3 = null;

            XDocument xml = XDocument.Parse(msg);
            var q = from x in xml.Elements("root").Descendants()
                    select x;
            foreach (var elem in q)
            {

                ip = elem.Attributes().ElementAt(0).Value;
                port = elem.Attributes().ElementAt(1).Value;
                name = elem.Attributes().ElementAt(2).Value;
                cpu = elem.Attributes().ElementAt(3).Value;
                if (IPtoPeer.Count > 0)
                {
                    if (!NametoIP.Contains(name))
                    {
                        InsertPeer(ip, port, name, cpu);
                        if (IPtoPeer.Count == 2)
                            SetBackup(ip + ":" + port);

                        MessageGenerator temp = new MessageGenerator();
                        string mMsg = temp.msgIPtoPeer(IPtoPeer);
                        string master = temp.msgMaster(GetMaster());
                        string backup = temp.msgBackup(GetBackup());
                        AsynchronousClient client1 = new AsynchronousClient();
                        client1.SetMultiMsg(IPtoPeer, mMsg, mPeer.mIP + ":" + mPeer.mPort);
                        t1 = new Thread(new ThreadStart(client1.SendMultiClient));
                        t1.Start();
                        t1.IsBackground = true;
                        AsynchronousClient client2 = new AsynchronousClient();
                        client2.SetSingleMsg(ip, port, master);
                        t2 = new Thread(new ThreadStart(client2.SendSingleClient));
                        t2.Start();
                        t2.IsBackground = true;
                        AsynchronousClient client3 = new AsynchronousClient();
                        client3.SetSingleMsg(ip, port, backup);
                        t3 = new Thread(new ThreadStart(client3.SendSingleClient));
                        t3.Start();
                        t3.IsBackground = true;
                    }
                    else
                    {
                        MessageGenerator temp = new MessageGenerator();
                        string error = temp.msgError("10:Username Already Exists");
                        AsynchronousClient client = new AsynchronousClient();
                        client.SetSingleMsg(ip, port, error);
                        t1 = new Thread(new ThreadStart(client.SendSingleClient));
                        t1.Start();
                        t1.IsBackground = true;
                    }
                }
                else
                {
                    MessageGenerator temp = new MessageGenerator();
                    string error = temp.msgError("10:Peer is not a part of Swarm");
                    AsynchronousClient client = new AsynchronousClient();
                    client.SetSingleMsg(ip, port, error);
                    t1 = new Thread(new ThreadStart(client.SendSingleClient));
                    t1.Start();
                    t1.IsBackground = true;
                }
            }
            showTable();
        }
        private void getIPtoPeerMsg(String msg)
        {
            String ip;
            String port;
            String name;
            String cpu;

            XDocument xml = XDocument.Parse(msg);
            var q = from x in xml.Elements("root").Descendants()
                    select x;
            foreach (var elem in q)
            {
                ip = elem.Attributes().ElementAt(0).Value;
                port = elem.Attributes().ElementAt(1).Value;
                name = elem.Attributes().ElementAt(2).Value;
                cpu = elem.Attributes().ElementAt(3).Value;
                InsertPeer(ip, port, name, cpu);
            }
            showTable();
        }

        private void getHeartBeatRequestMsg(String msg)
        {
            Thread t;
            string ipport = GetIP() + ":" + GetPort();
            string target = " ";
            string reply = " ";
            XDocument xml = XDocument.Parse(msg);
            var q = from x in xml.Descendants()
                    where (x.Name == "root")
                    select x;
            foreach (var elem in q)
                target = elem.Value;
            MessageGenerator temp = new MessageGenerator();
            reply = temp.msgHeartBeatReply(ipport);
            AsynchronousClient client = new AsynchronousClient();
            string[] str = target.Split(':');
            string ip = str[0];
            string port = str[1];
            client.SetSingleMsg(ip, port, reply);
            t = new Thread(new ThreadStart(client.SendSingleClient));
            t.IsBackground = true;
            t.Start();
            
        }

        private void getHeartBeatReplyMsg(String msg) 
        {
            string target="";
            XDocument xml = XDocument.Parse(msg);
            var q = from x in xml.Descendants()
                    where (x.Name == "root")
                    select x;
            foreach (var elem in q)
                target = elem.Value;
            Console.WriteLine(target);
            string receivetime = DateTime.Now.ToLongTimeString() + ":" + DateTime.Now.Millisecond.ToString();
            InsertReceiveTime(target, receivetime);
            showHeartBeat(target);
        }

        private void getMasterMsg(String msg)
        {
            string master = " ";
            XDocument xml = XDocument.Parse(msg);
            var q = from x in xml.Descendants()
                    where (x.Name == "root")
                    select x;
            foreach (var elem in q)
                master = elem.Value;
            SetMaster(master);
            showTable();
        }

        private void getBackupMsg(String msg)
        {
            string backup = " ";
            XDocument xml = XDocument.Parse(msg);
            var q = from x in xml.Descendants()
                    where (x.Name == "root")
                    select x;
            foreach (var elem in q)
                backup = elem.Value;
            SetBackup(backup);
            showTable();
        }

        //public void getRun(ref Peer mPeer) 
        //{
        //    string temp;
        //    string ipport = mPeer.GetIP() + mPeer.GetPort();
        //    string pid = " ";
        //    XDocument xml = XDocument.Parse(msg);
        //    var q = from x in xml.Descendants()
        //            where (x.Name == "root")
        //            select x;
        //    foreach (var elem in q)
        //        pid = elem.Value;
        //    temp = mPeer.GetFlag(pid);

        //    if (temp == "0")
        //    {
        //        mPeer.SetFlag(pid, "1");
        //        string smsg = mMsg.msgRunSucessReply(pid,ipport);
        //    }
        //    else
        //    {
        //        string smsg = mMsg.msgRunFailReply(pid, ipport);
        //    }
        //}

        //public void getRunFail()
        //{
        //    string pid = " ";
        //    XDocument xml = XDocument.Parse(msg);
        //    var q = from x in xml.Descendants()
        //            where (x.Name == "root")
        //            select x;
        //    foreach (var elem in q)
        //        pid = elem.Value;
        //}

        //public void getRunSucess()
        //{
        //    string pid = " ";
        //    XDocument xml = XDocument.Parse(msg);
        //    var q = from x in xml.Descendants()
        //            where (x.Name == "root")
        //            select x;
        //    foreach (var elem in q)
        //        pid = elem.Value;
        //}

        //public void getReRun(ref Peer mPeer)
        //{
        //    string pid = " ";
        //    XDocument xml = XDocument.Parse(msg);
        //    var q = from x in xml.Descendants()
        //            where (x.Name == "root")
        //            select x;
        //    foreach (var elem in q)
        //        pid = elem.Value;
        //    mPeer.SetFlag(pid, "0");
        //}

        private void getChatMsg(String msg) 
        {
            string chat = "";
            string ip = "";
            XDocument xml = XDocument.Parse(msg);
            //var q = from x in xml.Descendants()
            //        where (x.Name == "root")
            //        select x;
            //foreach (var elem in q)
            //    chat = elem.Value;
            var q = from x in xml.Elements("root").Descendants()
                    select x;
            foreach (var elem in q)
            {

                ip = elem.Attributes().ElementAt(0).Value;
                chat = elem.Attributes().ElementAt(1).Value;
            }
            string name = "";
            Peer temp = new Peer();
            temp = (Peer)GetIPtoPeer()[ip];
            name = temp.mName;
            Console.WriteLine("{0}:{1}",name,chat);
            ////////////////////////////////////////////////
            if (ChatChanged != null)
                ChatChanged(name,chat);

            //
        }

        private void getErrorMsg(String msg)
        {
            string error = " ";
            XDocument xml = XDocument.Parse(msg);
            var q = from x in xml.Descendants()
                    where (x.Name == "root")
                    select x;
            foreach (var elem in q)
                error = elem.Value;
            string[] sr = error.Split(':');
            int errorCode = Convert.ToInt32(sr[0]);
            string errorMsg = sr[1];
           // Console.WriteLine(error);
            ////////////////////////!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!////////////////
            if (ErrorChanged != null)
                ErrorChanged(errorCode,errorMsg);


            /////////
        }

        private void getDisconnectMsg(String msg)
        {
            string ipport = " ";
            XDocument xml = XDocument.Parse(msg);
            var q = from x in xml.Descendants()
                    where (x.Name == "root")
                    select x;
            foreach (var elem in q)
                ipport = elem.Value;
            setMasterBackup(ipport);
            showTable();
        }
        private void showHeartBeat(String ipport)
        {
            if(IPtoHeartbeat.Contains(ipport))
            {
                Heartbeat temp=(Heartbeat)IPtoHeartbeat[ipport];
                Console.WriteLine("sendtime: {0}----receivetime: {1}", temp.SendTime, temp.ReceiveTime);
            }
        }


        private void showTable()
        {
            foreach (Object ip in IPtoPeer.Keys)
            {
                Peer mPeer = (Peer)IPtoPeer[ip];
                Console.Write("{0} ---> IP:{1},Port:{2},Name:{3},CPU:{4}\n", 
                    ip, mPeer.mIP, mPeer.mPort, mPeer.mName, mPeer.mCPU);
            }
            Console.Write("Master: {0} ; Backup: {1}\n", GetMaster(), GetBackup());
        }
        private String selectbackup()
        {
            string backup = "";
            string master = GetMaster();
            if (IPtoPeer.Count == 1)
            {
                return backup;
            }
            else
            {
                foreach (string IP in IPtoPeer.Keys)
                {
                    if (IP != master)
                    {
                        backup = IP;
                    }
                }
                foreach (string IPs in IPtoPeer.Keys)
                {
                    if (IPs != master)
                    {
                        int comp = IPs.CompareTo(backup);
                        if (comp < 0)
                            backup = IPs;
                    }
                }
                return backup;
            }
        }
        private void setMasterBackup(String ipport)
        {
            if (ipport == GetMaster())
            {
                SetMaster(GetBackup());
                RemovePeer(ipport);
                string backup = selectbackup();
                SetBackup(backup);
            }
            else if (ipport == GetBackup())
            {
                RemovePeer(ipport);
                string backup = selectbackup();
                SetBackup(backup);
            }
            else
            {
                RemovePeer(ipport);
            }
        }
    }
}
